create definer = ``@`` view tidb_mdl_view as
(
SELECT `job_id`                                         AS `job_id`,
       `db_name`                                        AS `db_name`,
       `table_name`                                     AS `table_name`,
       `query`                                          AS `query`,
       `session_id`                                     AS `session_id`,
       `txnstart`                                       AS `txnstart`,
       TIDB_DECODE_SQL_DIGESTS(`all_sql_digests`, 4096) AS `SQL_DIGESTS`
FROM ((`information_schema`.`ddl_jobs`) JOIN `information_schema`.`cluster_tidb_trx`)
         JOIN `information_schema`.`cluster_processlist`
WHERE (`ddl_jobs`.`state` != _UTF8MB4'synced' AND `ddl_jobs`.`state` != _UTF8MB4'cancelled')
  AND FIND_IN_SET(`ddl_jobs`.`table_id`, `cluster_tidb_trx`.`related_table_ids`)
  AND `cluster_tidb_trx`.`session_id` = `cluster_processlist`.`id`);

